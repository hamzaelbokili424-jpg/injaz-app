const http = require('node:http');
const fs = require('node:fs');
const path = require('node:path');
const { URL } = require('node:url');
const PORT = Number(process.env.PORT || 3000);
const HOST = '0.0.0.0';
const INDEX = path.join(__dirname, 'index.html');
const MAX_BODY = 30_000;
const WINDOW_MS = 60_000;
const MAX_REQUESTS = 20;
const buckets = new Map();
function json(res, status, obj) { res.writeHead(status, {'content-type':'application/json; charset=utf-8','cache-control':'no-store','x-content-type-options':'nosniff'}); res.end(JSON.stringify(obj)); }
function readBody(req) { return new Promise((resolve, reject) => { let data=''; req.on('data', c => { data += c; if (data.length > MAX_BODY) { reject(new Error('BODY_TOO_LARGE')); req.destroy(); } }); req.on('end', () => { try { resolve(JSON.parse(data || '{}')); } catch { reject(new Error('BAD_JSON')); } }); req.on('error', reject); }); }
function allowed(ip) { const now=Date.now(); let b=buckets.get(ip); if(!b || now-b.start>WINDOW_MS) b={start:now,count:0}; b.count++; buckets.set(ip,b); if (buckets.size>5000) for (const [k,v] of buckets) if(now-v.start>WINDOW_MS) buckets.delete(k); return b.count<=MAX_REQUESTS; }
const server = http.createServer(async (req,res) => {
  const url = new URL(req.url, `http://${req.headers.host || 'localhost'}`);
  if (req.method==='GET' && url.pathname==='/health') return json(res,200,{ok:true});
  if (req.method==='GET' && (url.pathname==='/' || url.pathname==='/index.html')) { res.writeHead(200, {'content-type':'text/html; charset=utf-8','x-content-type-options':'nosniff','referrer-policy':'strict-origin-when-cross-origin','content-security-policy':"default-src 'self'; connect-src 'self'; img-src 'self' data:; style-src 'self' 'unsafe-inline'; script-src 'self' 'unsafe-inline'; base-uri 'self'; form-action 'self'; frame-ancestors 'none'"}); return fs.createReadStream(INDEX).pipe(res); }
  if (req.method==='POST' && url.pathname==='/api/chat') {
    const ip = (req.headers['x-forwarded-for'] || req.socket.remoteAddress || 'unknown').toString().split(',')[0].trim();
    if (!allowed(ip)) return json(res,429,{error:'تم تجاوز عدد الطلبات مؤقتًا. حاول بعد دقيقة.'});
    if (!process.env.OPENAI_API_KEY) return json(res,503,{error:'المدرب الذكي غير مفعّل بعد. يجب على مالك التطبيق إضافة مفتاح OpenAI في إعدادات الاستضافة.'});
    let body; try { body=await readBody(req); } catch(e) { return json(res,e.message==='BODY_TOO_LARGE'?413:400,{error:'تعذّر قراءة الرسالة.'}); }
    const styles = {strict:'كن مدربًا حازمًا وواضحًا، دون إهانة أو إذلال.', balanced:'كن متوازنًا وعمليًا: تشجيع صادق مع خطوات واضحة.', kind:'كن لطيفًا ومتفهمًا ومشجعًا دون مبالغة.'};
    const style = styles[body.style] || styles.balanced;
    const messages = Array.isArray(body.messages) ? body.messages.slice(-16) : [];
    const clean = messages.filter(m=>m && ['user','assistant'].includes(m.role) && typeof m.content==='string').map(m=>({role:m.role,content:m.content.slice(0,4000)}));
    if (!clean.length || clean[clean.length-1].role!=='user') return json(res,400,{error:'أرسل رسالة أولًا.'});
    try {
      const r = await fetch('https://api.openai.com/v1/chat/completions',{method:'POST',headers:{'authorization':`Bearer ${process.env.OPENAI_API_KEY}`,'content-type':'application/json'},body:JSON.stringify({model:process.env.OPENAI_MODEL || 'gpt-4o-mini',temperature:0.7,max_tokens:500,messages:[{role:'system',content:`أنت المدرب الذكي في تطبيق إنجاز للعادات والتحديات. تحدث بالعربية وبأسلوب طبيعي. افهم الرسائل الأخيرة وسياقها، ولا تستخدم ردودًا جاهزة عشوائية. اسأل سؤالًا توضيحيًا عند الحاجة، وقدّم خطوات عملية صغيرة ومناسبة. ${style} لا تشجع الحرمان من الطعام أو التمارين المفرطة أو إيذاء النفس. لا تدّع أنك تتذكر محادثات خارج السجل المرسل.`},...clean]})});
      const data=await r.json().catch(()=>({}));
      if(!r.ok) { console.error('OpenAI error status:',r.status); return json(res,502,{error:'تعذّر على المدرب الرد الآن. حاول لاحقًا.'}); }
      const reply=data.choices?.[0]?.message?.content?.trim();
      if(!reply) return json(res,502,{error:'لم يصل رد صالح من المدرب. حاول مرة أخرى.'});
      return json(res,200,{reply});
    } catch(e) { console.error('AI request failed:',e.message); return json(res,502,{error:'حدث اتصال غير متوقع. حاول مرة أخرى.'}); }
  }
  json(res,404,{error:'الصفحة غير موجودة'});
});
server.listen(PORT,HOST,()=>console.log(`INJAZ listening on ${HOST}:${PORT}`));
